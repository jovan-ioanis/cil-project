"""
    Team OpinionatedAnalysts.

    Data loading and general marshaling.

    Instead of using the raw text files, we use some files of processed tweets.
    Each processed tweet is just a list of word IDs. A dictionary provides the
    association between word ID and word.

    This implies that we need to create these files first. This can be done
    simply by calling rewrite() once. After that the files are present and you
    don't need to call it on further runs.
"""

import os
import os.path
import fnmatch
import random
import pickle
import numpy as np
from collections import Counter

# Where the data is located
DATA_ROOT = '../data'
# Files with training data (positive or negative)
TRAIN_RAW = 'train_%s_full.txt'
# Test data (for submission)
TEST_RAW = 'test_data.txt'

# Processed data paths
# The number in the filename is the vocab size
TRAIN_PROCESSED = 'train_%d.pkl'
TEST_PROCESSED = 'test_%d.pkl'
DIC = 'dic_%d.pkl'

class Dic:
    '''
    Holds word <-> id associations.
    '''

    def __init__(self, words=None):
        self.word_to_id = {}
        self.id_to_word = []

        if words is not None:
            self.id_to_word = words
            for i, w in enumerate(words):
                self.word_to_id[w] = i


    def add(self, w):
        '''
        Add a word to this dictionary.
        '''
        self.word_to_id[w] = len(self.id_to_word)
        self.id_to_word.append(w)

def process_tweet(s, dic):
    '''
    A processed tweet is a list of numbers, where each number refers to a word in
    the dictionary. This function constructs the processed tweet from a string.

    If a word of the tweet is not in the given dictionary, it is replaced with
    the string "<unk>". In addition, the processed tweet starts with <bos> and
    ends with <eos>.
    '''
    toks = s[:-1].split(' ')
    res = [dic.word_to_id['<bos>']]
    for t in toks:
        idx = dic.word_to_id.get(t, dic.word_to_id['<unk>'])
        res.append(idx)

    res.append(dic.word_to_id['<eos>'])
    return res

def recreate_tweet(tweet, dic):
    '''
    From a list of word IDs, recreate the original tweet.
    '''
    def get(l, i, d):
        return (l[i] if i < len(l) else d)
    return ' '.join([get(dic.id_to_word, x, '<???>') for x in tweet])

def write_object(what, where):
    '''
    Pickle a single object in the given path.
    '''
    with open(os.path.join(DATA_ROOT, where), 'wb') as f:
        pickle.dump(what, f)

def read_object(where):
    '''
    Unpickle a single object from the given path.
    '''
    with open(os.path.join(DATA_ROOT, where), 'rb') as f:
        return pickle.load(f)

def read_object_from_any(where):
    '''
    Attempt to find a file containing the given string, and unpickle a single
    object from it if it exists.

    If more than one file matches, only one is loaded, arbitrarily. This might
    cause some problems.
    '''
    for f in os.listdir(DATA_ROOT):
        if fnmatch.fnmatch(f, '*' + where + '*'):
            with open(os.path.join(DATA_ROOT, f), 'rb') as f:
                return pickle.load(f)

    raise RuntimeError('Could not find file matching ' + where)

def get_counts(f, counter):
    for ln in open(f, encoding='utf8'):
        for w in ln.split():
            counter[w] = counter.get(w, 0) + 1

def exists(path):
    '''
    Check whether the given file exists in the data folder.
    '''
    full = os.path.join(DATA_ROOT, path)
    return os.path.isfile(full)

def processed_exists(vocab_limit):
    '''
    Check whether the processed training, testing and dictionary
    data exist in the given folder.
    '''
    return (exists(TRAIN_PROCESSED % vocab_limit)
        and exists(TEST_PROCESSED % vocab_limit)
        and exists(DIC % vocab_limit))

def rewrite(vocab_limit):
    '''
    Take all the samples in the raw text files and process them
    '''
    train_pos_f = os.path.join(DATA_ROOT, TRAIN_RAW % 'pos')
    train_neg_f = os.path.join(DATA_ROOT, TRAIN_RAW % 'neg')
    test_f = os.path.join(DATA_ROOT, TEST_RAW)

    vocab_counts = Counter()
    get_counts(train_pos_f, vocab_counts)
    get_counts(train_neg_f, vocab_counts)
    get_counts(test_f, vocab_counts)

    # Keep space for <unk>, <pad>, <eos>, <bos>
    top = vocab_counts.most_common(vocab_limit - 4)

    dic = Dic([x for x, _ in top])
    dic.add('<bos>')
    dic.add('<eos>')
    dic.add('<pad>')
    dic.add('<unk>')

    # List of tuples of (processed tweet, label) with label either 1 or -1
    train = []
    # List of tuples of (processed tweet, id) with the id of the test sample
    test = []


    # This ensures that we have examples from each class if we limit the amount
    # of data we use for training/inference.
    with open(train_neg_f, encoding='utf8') as neg_f, open(train_pos_f, encoding='utf8') as pos_f:

        while True:
            neg_ln = neg_f.readline()
            pos_ln = pos_f.readline()

            # This assumes that there is the same amount of positive/negative
            # examples
            if not neg_ln:
                break

            train.append((process_tweet(neg_ln, dic), -1))
            train.append((process_tweet(pos_ln, dic), 1))

    for ln in open(test_f, encoding='utf8'):
        # Separate the ID of the test case from the actual tweet.
        i = ln.find(',')
        test.append((process_tweet(ln[i + 1:], dic), int(ln[:i])))

    # Dump as binaries
    write_object(train, TRAIN_PROCESSED % vocab_limit)
    write_object(test, TEST_PROCESSED % vocab_limit)
    write_object(dic, DIC % vocab_limit)


def load_train(vocab_limit):
    return read_object(TRAIN_PROCESSED % vocab_limit)

def load_test(vocab_limit):
    return read_object(TEST_PROCESSED % vocab_limit)

def load_dic(vocab_limit):
    return read_object(DIC % vocab_limit)

def generate_submission(Yhat, ids):
    f = open('submission.csv', 'w')
    f.write('ID,Prediction\n')
    for index, id in enumerate(ids):
        f.write('%d,%d\n' % (id, Yhat[index]))

    f.close()

