Baseline approach -- team OpinionatedAnalysts

All paths relative to this file.

Directory structure:
  This script expects a ../data folder containing:
    - train_neg_full.txt
    - train_pos_full.txt
    - test_data.txt
    - gnews-vecs-neg300.bin

  The first three files, you have.
  The Google News pretrained embeddings can be found here:
    https://drive.google.com/file/d/0B7XkCwpI5KDYNlNUTTlSS21pQmM/edit

Dependencies:
  Python 3.5
  gensim 1.0.1
  numpy 1.12.1
  sklearn 0.17.1

Parameters (within baseline.py)
  LIMIT: number of tweets to train on
  VOCAB: vocabulary size

How to run:
  python3 baseline.py

Result:
  submission.csv will be created in this folder.
