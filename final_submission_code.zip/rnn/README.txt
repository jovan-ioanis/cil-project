Advanced GRU RNN model -- team OpinionatedAnalysts

All paths relative to this file.

Directory structure:
    This script expects:
        1. ./data folder containing:
            - train_neg_full.txt
            - train_pos_full.txt
            - train_neg.txt
            - train_pos.txt
            - test_data.txt
            - gnews-vecs-neg300.bin

        The first five files, you have. The Google News pretrained embeddings can be found here:
            https://drive.google.com/file/d/0B7XkCwpI5KDYNlNUTTlSS21pQmM/edit

        2. ./logs folder containing:
            - exp-1-training-2017-06-19_04-36-12
                * exp-1-2017-06-19_04-36-12-ep-4.ckpt-78000.meta
                * exp-1-2017-06-19_04-36-12-ep-4.ckpt-78000.index
                * exp-1-2017-06-19_04-36-12-ep-4.ckpt-78000.data-00000-of-00001
            - exp-1-training-2017-06-27_13-41-06
                * exp-1-2017-06-27_13-41-06-ep-4.ckpt-100500.meta
                * exp-1-2017-06-27_13-41-06-ep-4.ckpt-100500.index
                * exp-1-2017-06-27_13-41-06-ep-4.ckpt-100500.data-00000-of-00001

        3. ./pickled_vars folder containing:
            - index2word.p
            - vocab.p
            - word2index.p

        4. ./word2vec folder containing:
            - word_embeddings_full_200.word2vec
            - word_embeddings_full_200.word2vec.syn1neg.npy
            - word_embeddings_full_200.word2vec.wv.syn0.npy

        The logs, pickled_vars and word2vec folders can be found here:
            https://drive.google.com/open?id=0B2Cv2-ukPoJrTEt6SFhVQXFmSGM

Dependencies:
    Python 3.5.2
    Tensorflow 1.0.0
    gensim 1.0.1
    numpy 1.12.1
    tqdm 4.14.0
    nltk 3.2.2

Configuration:
    All configuration options are set in configuration.py

How to run:
    1. Set configurations in configuration.py
    2. python3 main.py

Result:
    submission.csv will be created in ./submissions folder.

    NOTE: Some inconsistencies may exist between the newly generated submission.csv files, and the ones selected on
          kaggle, due to changes in the word embeddings and the pickles.
